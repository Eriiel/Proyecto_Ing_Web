<?php
// Incluir conexión a la base de datos
require 'includes/db_connection.php';

// Obtener y validar el ID de la mascota desde la URL
$mascota_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($mascota_id === 0) {
    header('Location: galeria.php');
    exit();
}

try {
    // Consultar información de la mascota usando PDO
    $stmt = $pdo->prepare("SELECT * FROM mascotas WHERE id = ? AND estado = 'Disponible'");
    $stmt->execute([$mascota_id]);
    $mascota = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$mascota) {
        header('Location: galeria.php');
        exit();
    }
} catch (PDOException $e) {
    die("Error al obtener la información de la mascota: " . $e->getMessage());
}

// Función para emoji
function obtenerEmoji($especie) {
    switch (strtolower($especie)) {
        case 'perro': return '🐕';
        case 'gato': return '🐈';
        default: return '🐾';
    }
}

// Definir variables para la plantilla
$page_title = 'Solicitud de Adopción para ' . htmlspecialchars($mascota['nombre']);
$active_page = 'galeria';

// Incluir el header
include 'includes/header.php';
?>

<!-- BREADCRUMB -->
<nav class="breadcrumb">
    <div class="container">
        <ul class="breadcrumb-list">
            <li><a href="index.php">Inicio</a></li>
            <li class="breadcrumb-separator">›</li>
            <li><a href="galeria.php">Galería</a></li>
            <li class="breadcrumb-separator">›</li>
            <li class="breadcrumb-current">Solicitud de Adopción</li>
        </ul>
    </div>
</nav>

<!-- FORM SECTION -->
<section class="form-section">
    <div class="container">
        <div class="pet-info-card">
            <div class="pet-image-small">
                <?php if (!empty($mascota['foto'])): ?>
                    <img src="uploads/<?= htmlspecialchars($mascota['foto']); ?>" alt="<?= htmlspecialchars($mascota['nombre']); ?>">
                <?php else: ?>
                    <?= obtenerEmoji($mascota['especie']); ?>
                <?php endif; ?>
            </div>
            <div class="pet-info-text">
                <h2>Estás aplicando para adoptar a: <strong><?= htmlspecialchars($mascota['nombre']); ?></strong></h2>
            </div>
        </div>

        <div class="form-card">
            <h1 class="form-title">Formulario de Adopción</h1>
            <p class="form-subtitle">Por favor, completa todos los campos con la mayor sinceridad posible. Esto nos ayuda a asegurar el mejor futuro para nuestras mascotas.</p>

            <form id="adoptionForm" method="POST" action="procesar_Adopcion.php">
                <input type="hidden" name="id_mascota" value="<?= $mascota_id; ?>">

                <div class="form-group">
                    <label for="nombre_solicitante">Nombre Completo <span class="required">*</span></label>
                    <input type="text" id="nombre_solicitante" name="nombre_solicitante" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="email_solicitante">Correo Electrónico <span class="required">*</span></label>
                        <input type="email" id="email_solicitante" name="email_solicitante" required>
                    </div>
                    <div class="form-group">
                        <label for="telefono_solicitante">Teléfono <span class="required">*</span></label>
                        <input type="tel" id="telefono_solicitante" name="telefono_solicitante" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="direccion_solicitante">Dirección <span class="required">*</span></label>
                    <input type="text" id="direccion_solicitante" name="direccion_solicitante" required>
                </div>
                
                <div class="form-group">
                    <label for="motivo_adopcion">¿Por qué quieres adoptar a <?= htmlspecialchars($mascota['nombre']); ?>? <span class="required">*</span></label>
                    <textarea id="motivo_adopcion" name="motivo_adopcion" required placeholder="Cuéntanos por qué te interesa esta mascota y cómo sería su vida contigo..."></textarea>
                </div>

                <div class="form-actions">
                    <!-- ESTE ES EL BOTÓN QUE USA LA CLASE CORRECTA -->
                    <a href="galeria.php" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Enviar Solicitud</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php
// Incluye el footer
include 'includes/footer.php';
?>